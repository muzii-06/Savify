import pandas as pd
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from docx import Document

# Load the synthetic dataset
df = pd.read_csv(r'C:\Users\USER 1\Desktop\final\Synthetic_Negotiation_Dataset (1).csv')

# Features and target variable
X = df[['account_age_days', 'total_orders', 'product_rating']]
y = df['discount_percent']

# Split the data into training and test sets (80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Convert data into DMatrix format for XGBoost (optimized for performance)
dtrain = xgb.DMatrix(X_train, label=y_train)
dtest = xgb.DMatrix(X_test, label=y_test)

# Set up XGBoost parameters
params = {
    'objective': 'reg:squarederror',  # Regression problem with squared error
    'max_depth': 6,                   # Maximum depth of the trees
    'learning_rate': 0.1,             # Step size for each iteration
    'n_estimators': 100,              # Number of boosting rounds
    'eval_metric': 'rmse',            # Evaluation metric: RMSE (Root Mean Squared Error)
    'colsample_bytree': 0.8,          # Fraction of features to consider at each split
    'subsample': 0.8                  # Fraction of samples to consider for each tree
}

# Define evaluation sets for monitoring training
evals = [(dtrain, 'train'), (dtest, 'test')]

# Train the model and track training history
history = {}
model = xgb.train(params, dtrain, num_boost_round=100, evals=evals, 
                  evals_result=history, early_stopping_rounds=10)

# Predict on the test set
y_pred = model.predict(dtest)

# Calculate performance metrics
mse = mean_squared_error(y_test, y_pred)
rmse = mse ** 0.5
r2 = r2_score(y_test, y_pred)

# Create Word document for model and training details
doc = Document()
doc.add_heading('XGBoost Model Training Documentation', 0)

# Add sections to the document
doc.add_heading('1. Model Overview', level=1)
doc.add_paragraph('This document outlines the details of the XGBoost regression model used '
                  'to predict the discount percentage based on account age, total orders, and product rating.')

doc.add_heading('2. Model Parameters', level=1)
params_section = "The model uses the following parameters:\n"
params_section += "\n".join([f"{key}: {value}" for key, value in params.items()])
doc.add_paragraph(params_section)

doc.add_heading('3. Training Process', level=1)
doc.add_paragraph('The model was trained using the following process:\n'
                  '- Data was split into training (80%) and test (20%) sets.\n'
                  '- Early stopping was used to prevent overfitting (stopping after 10 rounds without improvement).\n'
                  '- Evaluation metrics during training included RMSE (Root Mean Squared Error).')

doc.add_heading('4. Training History', level=1)
doc.add_paragraph('The following shows the training history (RMSE) during the model training process:')

history_section = ""
for metric, values in history['test'].items():
    history_section += f"{metric}: {values[-1]:.4f}\n"
doc.add_paragraph(history_section)

doc.add_heading('5. Model Evaluation', level=1)
doc.add_paragraph(f"Performance on the test set:\nRMSE: {rmse:.4f}\nR2 Score: {r2:.4f}")

# Add detailed explanations for metrics
doc.add_heading('6. Evaluation Metrics', level=1)
doc.add_paragraph('The following evaluation metrics were calculated for the model:\n'
                  '- RMSE: Root Mean Squared Error, which measures the average magnitude of the error.\n'
                  '- R2 Score: Coefficient of Determination, which indicates how well the model fits the data.')

# Save the model and document
doc_filename = "xgboost_negotiation_model_documentation.docx"
doc.save(doc_filename)

# Save the model for future use
model.save_model('xgboost_negotiation_model.json')

print(f"Training completed. The model and documentation have been saved.\nModel file: xgboost_negotiation_model.json\nDocumentation: {doc_filename}")
