import xgboost as xgb
import pandas as pd  # Import pandas

# Load the trained model
model = xgb.Booster()
model.load_model('xgboost_negotiation_model.json')

# Function to calculate the discounted price based on rounds and max discount
def calculate_discounted_price(original_price, account_age_days, total_orders, product_rating, max_discount, rounds):
    # Prepare the input data for prediction
    input_data = pd.DataFrame({
        'account_age_days': [account_age_days],
        'total_orders': [total_orders],
        'product_rating': [product_rating]
    })
    
    # Convert the input data into DMatrix format for prediction
    dinput = xgb.DMatrix(input_data)
    
    # Predict the discount percentage
    predicted_discount = model.predict(dinput)[0]
    
    # Apply max discount set by seller
    predicted_discount = min(predicted_discount, max_discount / 100.0)  # max_discount is in percentage
    
    # Calculate the discount per round
    discount_per_round = predicted_discount / rounds
    
    # Initialize the final discounted price
    final_price = original_price
    
    # Apply the discount over the rounds
    for round_num in range(1, rounds + 1):
        if round_num == rounds:
            # In the last round, apply the final discount
            final_price -= final_price * (predicted_discount - (rounds - 1) * discount_per_round)
        else:
            # Apply the divided discount for intermediate rounds
            final_price -= final_price * discount_per_round
    
    # Return the final discounted price
    return final_price, predicted_discount * 100  # Returning discount in percentage

# Test example with user data
original_price = 100  # Example product price in currency
account_age_days = 10  # Example account age in days
total_orders = 1  # Example total orders
product_rating = 5.0  # Example product rating (1 to 5 scale)
max_discount = 20  # Max discount allowed by the seller (in percentage)
rounds = 2  # Number of negotiation rounds set by the seller

# Calculate the discounted price
discounted_price, applied_discount = calculate_discounted_price(
    original_price, account_age_days, total_orders, product_rating, max_discount, rounds
)

# Output the results
print(f"Original Price: {original_price} units")
print(f"Applied Discount: {applied_discount:.2f}% (predicted discount is capped by max discount)")
print(f"Discounted Price after {rounds} rounds: {discounted_price:.2f} units")
