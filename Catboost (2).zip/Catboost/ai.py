import pandas as pd
import numpy as np
from catboost import CatBoostRegressor, Pool
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt
import joblib

# === Step 1: Load Dataset ===
dataset_path = r"C:\Users\USER 1\Desktop\Catboost\realistic_negotiation_dataset_balanced_50k.csv"
df = pd.read_csv(dataset_path)

# === Step 2: Features & Target ===
features = [
    "product_price", "buyer_offer", "negotiation_round",
    "discount_margin_percent", "product_rating",
    "account_age_days", "total_orders"
]
target = "final_offer_price"

X = df[features]
y = df[target]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

train_pool = Pool(X_train, y_train)
test_pool = Pool(X_test, y_test)

# === Step 3: Extreme-Level CatBoost Model Configuration ===
model = CatBoostRegressor(
    iterations=1000,              # large number for deep learning
    learning_rate=0.05,
    depth=10,
    l2_leaf_reg=5,
    random_seed=42,
    eval_metric='RMSE',
    early_stopping_rounds=50,
    verbose=50
)

# === Step 4: Train Model ===
model.fit(train_pool, eval_set=test_pool)

# === Step 5: Evaluate ===
y_pred = model.predict(X_test)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f"\n✅ Model trained. Test RMSE: {rmse:.2f}")

# === Step 6: Save Model ===
model_path = r"C:\Users\USER 1\Desktop\Catboost\catboost_extreme_model.cbm"
model.save_model(model_path)
print(f"💾 Model saved to: {model_path}")

# === Step 7: Plot Training Loss ===
plt.figure(figsize=(10, 6))
plt.plot(model.get_evals_result()['learn']['RMSE'], label='Train RMSE')
plt.plot(model.get_evals_result()['validation']['RMSE'], label='Validation RMSE')
plt.xlabel("Iteration")
plt.ylabel("RMSE")
plt.title("Extreme-Level CatBoost Training Progress")
plt.grid(True)
plt.legend()
plot_path = r"C:\Users\USER 1\Desktop\Catboost\catboost_extreme_training_plot.png"
plt.savefig(plot_path)
plt.show()
print(f"📊 Training plot saved to: {plot_path}")
