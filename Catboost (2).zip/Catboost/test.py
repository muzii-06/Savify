import pandas as pd
from catboost import CatBoostRegressor
import joblib

# === Step 1: Load Trained CatBoost Model ===
model_path = r"C:\Users\USER 1\Desktop\Catboost\catboost_extreme_model.cbm"
model = CatBoostRegressor()
model.load_model(model_path)

# === Step 2: Define Initial Negotiation Inputs ===
original_price = 10000
product_price = original_price  # will be updated each round
discount_margin_percent = 20
product_rating = 2
buyer_offer = 600
account_age_days = 1000
total_orders = 9000

# === Negotiation Config ===
max_rounds = 5
round_num = 1
accepted = False
rejected = False
chat_log = []

# === Set Min Allowed Price from Original Price ===
min_allowed_price = round(original_price * (1 - discount_margin_percent / 100), 2)

print("\n🤝 AI-Based Buyer-Seller Negotiation Started")
print(f"📦 Product Price: ₹{original_price:.2f}")
print(f"🔒 Max Discount Allowed: ₹{original_price - min_allowed_price:.2f} ({discount_margin_percent}%)")

# === Negotiation Loop ===
while round_num <= max_rounds and not accepted and not rejected:
    print(f"\n🕐 Round {round_num}")
    print(f"📉 Price fed to model: ₹{product_price:.2f}")
    print(f"🧾 Buyer's current offer: ₹{buyer_offer:.2f}")

    # === Input Features Must Match Trained Model ===
    input_df = pd.DataFrame([{
        "product_price": product_price,
        "buyer_offer": buyer_offer,
        "negotiation_round": round_num,
        "discount_margin_percent": discount_margin_percent,
        "product_rating": product_rating,
        "account_age_days": account_age_days,
        "total_orders": total_orders
    }])

    prediction = model.predict(input_df)[0]
    raw_prediction = round(prediction, 2)

    # Clamp predicted offer within negotiation rules
    ai_offer = max(min(raw_prediction, product_price), buyer_offer, min_allowed_price)
    ai_offer = round(ai_offer, 2)

    print(f"🧠 Model raw prediction: ₹{raw_prediction}")
    print(f"🤖 Seller: My offer is ₹{ai_offer}")

    # Update product_price for next round
    product_price = ai_offer

    # === Buyer Decision ===
    decision = input("🧍‍♂️ Buyer: Type your decision (accept / reject / counter): ").strip().lower()

    chat_log.append({
        "Round": round_num,
        "Buyer Offer": round(buyer_offer, 2),
        "Seller Offer": ai_offer,
        "Buyer Decision": decision
    })

    if decision == "accept":
        print(f"\n✅ Deal accepted! Final price: ₹{ai_offer}")
        accepted = True
    elif decision == "reject":
        print("\n❌ Deal rejected. Negotiation ended.")
        rejected = True
    elif decision == "counter":
        try:
            new_offer = float(input("💬 Enter your counter offer (must be ≥ previous offer): ").strip())
            if new_offer < buyer_offer:
                print("⚠️ Your new offer must not be lower than your previous offer.")
            else:
                buyer_offer = new_offer
                round_num += 1
        except ValueError:
            print("⚠️ Invalid input. Please enter a valid number.")
    else:
        print("⚠️ Invalid decision. Please type: accept / reject / counter")

if not accepted and not rejected and round_num > max_rounds:
    print("\n⚠️ Max negotiation rounds reached. No agreement was made.")

# === Summary ===
print("\n📋 Negotiation Summary:")
print("-" * 60)
print(f"{'Round':<8}{'Buyer Offer':<15}{'Seller Offer':<15}{'Decision':<15}")
print("-" * 60)
for log in chat_log:
    print(f"{log['Round']:<8}₹{log['Buyer Offer']:<14.2f}₹{log['Seller Offer']:<14.2f}{log['Buyer Decision']:<15}")
print("-" * 60)
