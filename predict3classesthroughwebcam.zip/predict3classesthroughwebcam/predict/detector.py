import cv2
from ultralytics import YOLO

def main():
    # Define the path to your YOLOv11 model
    model_path = r"C:\Users\USER 1\Desktop\predict3classesthroughwebcam\predict\best.pt"  # Update with your actual model path
    
    # Set the confidence threshold (adjust here)
    conf_threshold = 0.8 # Set the desired confidence threshold (0.0 to 1.0)

    # Load the YOLOv11 model
    try:
        model = YOLO(model_path)
        print(f"Model loaded successfully from: {model_path}")
    except Exception as e:
        print(f"Error loading model: {e}")
        return

    # Initialize webcam
    cap = cv2.VideoCapture(0)  # 0 is the default webcam
    if not cap.isOpened():
        print("Error: Unable to access the webcam.")
        return

    print("Press 'q' to quit the webcam.")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Unable to read from the webcam.")
            break

        # Run object detection on the frame
        try:
            results = model.predict(source=frame, save=False, conf=conf_threshold)
            # Visualize results on the frame
            annotated_frame = results[0].plot()
        except Exception as e:
            print(f"Error during prediction: {e}")
            break

        # Display the frame with detections
        cv2.imshow("YOLOv11 Detection", annotated_frame)

        # Exit when 'q' key is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release resources
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
